from .PolyVecMesh import PolyVecMesh

# import sys
# sys.modules[__name__] = PolyVecMesh